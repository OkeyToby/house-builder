Cash Empire Simulator — Monetization Setup Guide
📍 Where the system is

Open Roblox Studio and go to:

ServerScriptService
→ GamepassesHandler


This script controls ALL Gamepasses in the game.

There is no separate module — everything is inside this file.

🧠 How this game handles Gamepasses

This game uses direct ID checks like this:

mps:UserOwnsGamePassAsync(player.UserId, 790426091)


That means:

🔴 Every Gamepass ID is hard-coded
If you don’t replace them everywhere, the pass will not work

🧩 Gamepasses used in this game

From the script:

Gamepass	ID
Double Money	790426091
Double Gems	790335102
VIP	790438067
Equip Slot 1	709100184
Equip Slot 2	790221164
Storage Slot 1	790229136
Storage Slot 2	788950995

These IDs appear multiple times in the file.

⚠️ CRITICAL RULE

You MUST replace every copy of every ID.
If even one is missed, the pass will:

Not activate

Not save

Not count for RobuxSpent

Not give rewards

✅ Correct way to replace IDs
Step 1 — Create your gamepasses

Go to:

Roblox Creator Dashboard
→ Your Game
→ Monetization
→ Gamepasses


Create new passes for:

Double Money

Double Gems

VIP

Equip Slot 1

Equip Slot 2

Storage 1

Storage 2

Copy all new IDs.

Step 2 — Use Search & Replace

In Roblox Studio press:

CTRL + SHIFT + F


Search for one ID, for example:

790426091


Replace it with your new Double Money ID.

Click Replace All.

Repeat for every ID in the table.

📊 Robux Spent Tracker

This part:

if mps:UserOwnsGamePassAsync(player.UserId, 790426091) then
    totalSpent = totalSpent + 249
end


This does NOT control price.
It only controls the RobuxSpent stat shown in-game.

You may edit these numbers to match your store pricing if you want.

Example:

totalSpent = totalSpent + 499

🧠 How purchases are applied

When a player buys a pass:

mps.PromptGamePassPurchaseFinished


The script:

Detects the ID

Enables the matching BoolValue inside:

player.Gamepasses


Adds multipliers like:

MoneyValue += 2
GemsValue += 2


So if IDs are correct → everything works automatically.

🧪 How to test

After replacing all IDs:

Publish the game

Buy a Gamepass

Rejoin

Check:

Player → Gamepasses


You should see:

DoubleMoney = true

VIP = true
etc.

🛑 Why this game breaks if IDs are wrong

This system is not dynamic.
It does NOT read from folders or modules.

It only works if every ID is correct everywhere.

That’s why your “search & replace all GamepassChecker IDs” method is the correct way to do it.